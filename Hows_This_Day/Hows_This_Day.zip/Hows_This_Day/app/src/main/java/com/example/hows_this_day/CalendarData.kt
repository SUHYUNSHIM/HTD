package com.example.hows_this_day

data class CalendarData(

    var Year: Int = 0 ,
    var Month: Int = 0,
    var Day: Int = 0
)